# Walletalk 设计系统 v1.1 · 前端接入说明

给 `clients/pc-web` 换皮用。PC 浏览器、Electron、H5 共用一套渲染层，所以这份包三端通用。
**只换皮，不改功能**：不动任何业务逻辑、接口、路由和功能性字符串。

在线文档（带白天 / 黑夜切换、全部组件和页面模板）：https://defitrail.github.io/im-preview/design-system/

**v1.1（2026-09-25，按项目方拍板更新）**

1. 自己发的消息气泡改为**琥珀实色 + 墨黑字**（`--wt-bubble-self-*`），聊天页橙色占比会超过标志规范建议的 15%，这是有意的选择。
2. 头像贴底、气泡带尾巴（v1.0 已是这样，确认保留）。
3. 白天 / 黑夜：**默认跟随系统，"个人设置"新增"外观"一项**（见 ③ 与第 7 节）。
4. 未读数用琥珀色（v1.0 已是这样，确认保留）。
5. 新增 **直播间**（第 8 节）与 **客服**（第 9 节）的页面稿与颜色收口表；图标 71 → 78 个。

---

## 1. 包里有什么

```
tokens/walletalk-tokens.css     令牌：白天（默认）+ 黑夜（data-theme="dark"）+ pc-web 旧变量映射
tokens/walletalk-tokens.json    同一份令牌的 JSON（设计工具、Flutter / 原生端可以用）
css/walletalk-signature.css     签名组件（钱包、状态灯、气泡尾巴、资产消息、红包）+ antd 补丁
antd/walletalk-antd-theme.ts    antd 5 主题：walletalkLight / walletalkDark（已在 antd 5.10.3 下类型检查、SSR 渲染通过）
tailwind/walletalk.preset.cjs   Tailwind 3 预设，兼容旧类名 bg-primary / text-primary
react/WtIcon.tsx                78 个图标的 React 组件，用法同 antd 图标
icons/svg/wt-*.svg              单个图标 SVG
icons/walletalk-icons.svg       图标 sprite
fonts/Outfit[wght].ttf + OFL.txt  品牌字体（SIL OFL，可商用、可随产品分发）
reference/ref.css · ref-extra.js  在线文档里参考实现的样式与结构（含直播间、客服），对照尺寸用（不用引入到项目）
```

## 2. 五步接入

### ① 放文件

```
src/styles/walletalk-tokens.css
src/styles/walletalk-signature.css
src/styles/walletalk-antd-theme.ts
src/components/WtIcon.tsx
walletalk.preset.cjs              ← 与 tailwind.config.js 同级
public/fonts/Outfit[wght].ttf
```

### ② 引入样式（src/main.tsx）

先删掉 `src/styles/global.scss` 里 `:root` 的 10 个颜色变量（`--chat-bubble` `--chat-bubble-sender` `--base-black` `--primary` `--primary-active` `--top-search-bar` `--sub-text` `--gap-text` `--warn-text` `--moment-text`），**保留** `--full-height` `--searchbar-height` `--mobile-tabbar-height`。这 10 个变量已在 `walletalk-tokens.css` 里重新定义并指向新令牌。

```ts
import "./styles/walletalk-tokens.css";     // 放在 index.scss 之前
import "./index.scss";
import "./styles/walletalk-signature.css";  // 放在 antd.scss 之后
```

字体（建议自托管，国内网络稳定）：

```css
@font-face {
  font-family: "Outfit";
  src: url("/fonts/Outfit[wght].ttf") format("truetype");
  font-weight: 400 700;
  font-display: swap;
}
```

中文不额外加载字体，走系统：苹方 / 微软雅黑（已在 `--wt-font-ui` 字体栈里）。等宽字体 Geist Mono 只用于地址和哈希，缺失时回退系统等宽。

### ③ antd 主题 + 白天 / 黑夜（src/App.tsx）

默认跟随系统，用户可在"个人设置 → 外观"里改成白天或黑夜。偏好放进现有的 `appSettings`（和 `locale` 同一处）。

```ts
// store/type.d.ts：AppSettings 加一个字段
theme?: "system" | "light" | "dark";
```

```tsx
import { walletalkLight, walletalkDark, resolveWalletalkMode, watchSystemTheme } from "@/styles/walletalk-antd-theme";

const pref = useUserStore((s) => s.appSettings.theme ?? "system");
const [mode, setMode] = useState(() => resolveWalletalkMode(pref));
useEffect(() => {
  setMode(resolveWalletalkMode(pref));
  return pref === "system" ? watchSystemTheme(setMode) : undefined;   // 跟随系统时监听切换
}, [pref]);
useEffect(() => { document.documentElement.dataset.theme = mode; }, [mode]);

<ConfigProvider
  theme={mode === "dark" ? walletalkDark : walletalkLight}
  autoInsertSpaceInButton={false}
  locale={antdLocales[locale] ?? enUS}
  renderEmpty={() => <BrandEmpty />}
>
```

持久化照 `locale` 的写法（`setLocale` / `getLocale` 存本机）。为了首屏不闪，在 `index.html` 的 `<head>` 里先读一次本机偏好并写 `data-theme`。

### ④ Tailwind（tailwind.config.js）

```js
module.exports = {
  presets: [require("./walletalk.preset.cjs")],
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  darkMode: "class",   // 保持不变。黑夜模式走 data-theme，不要给 <html> 加 .dark
  theme: { extend: { padding: {…}, margin: {…}, width: {…}, height: {…} } },  // 原有的保留
};
```

删掉原来 `extend.colors` 里的 `primary / primary-teal / primary-deep`（否则会覆盖预设）。新类名：

```
bg-wt-panel  bg-wt-chat  bg-wt-frame  bg-wt-active  bg-wt-input
text-wt-text-1 / -2 / -3  text-wt-brand-text  border-wt-line-1 / -2
bg-wt-brand  bg-wt-brand/10  text-wt-brand-on  rounded-wt-lg  shadow-wt-2  text-wt-body
```

### ⑤ 颜色收口

旧变量已自动映射（见第 3 节）。硬编码色按第 4 节的表机械替换。图标默认色改一处：

```ts
// src/constants/chatToolbarIcon.ts
color: "var(--wt-text-3)",
activeColor: "var(--wt-brand-text)",
```

## 3. 旧变量映射（已写在 walletalk-tokens.css）

| pc-web 变量 | 改为 | 说明 |
|---|---|---|
| `--primary` | `--wt-brand-text` | 40 处作文字 / 图标色。**另有 7 处作底色，要手动改**（见下） |
| `--primary-active` | `--wt-bg-active` | 42 处悬停 / 选中底 |
| `--top-search-bar` | `--wt-bg-frame` | 顶栏底色 |
| `--sub-text` | `--wt-text-3` | 110 处辅助文字 |
| `--gap-text` | `--wt-line-2` | 51 处描边 + 6 处分隔底 |
| `--base-black` | `--wt-text-1` | `html div` 全局文字色，随主题切换，黑夜下不再被压黑 |
| `--warn-text` | `--wt-danger` | 错误提示 |
| `--moment-text` | `--wt-brand-text` | 链接色 |
| `--chat-bubble` | `--wt-bg-subtle` | 33 处灰底（钱包、应用广场） |
| `--chat-bubble-sender` | `--wt-bubble-self-bg` | 自己的气泡底（琥珀实色；上面的文字用 `--wt-bubble-self-text`） |

`--primary` 作底色的 7 处，改成 `bg-[var(--wt-brand)]` + `text-[var(--wt-on-brand)]`（白字改墨黑字，白字在琥珀上只有 2.5:1）：

```
layout/CameraQrModal.tsx:188
styles/antd.scss:217, 222                     ← 可直接删除，signature.css 已接管
components/CSManagerConsole/index.tsx:1175, 1188
components/CSWorkbenchPanel/index.tsx:612, 625
```

## 4. 高频硬编码色替换表（不含 live.scss 与生成文件）

| 硬编码色 | 次数 | 替换为 |
|---|---|---|
| `#7C3AED` | 47 | 填充 `--wt-brand`；文字 / 图标 `--wt-brand-text` |
| `#6D28D9 #8B5CF6 #8759F2 #6366F1 #4F46E5` | 24 | `--wt-brand` / `--wt-brand-active` |
| `#2DD4BF #14B8A6`（紫→青渐变终点） | 13 | 删除渐变，改纯色 `--wt-brand` |
| `#667085` | 32 | `--wt-text-3` |
| `#8E9AB0 #8E9AAF #8D9BB0` | 20 | `--wt-text-3` |
| `#1F1F1F #1A2033 #0C1C33 #1F2329` | 26 | `--wt-text-1` |
| `#F4F5F7 #FAFBFD` | 21 | `--wt-bg-subtle` / `--wt-bg-panel` |
| `#F7F8FA` | 3 | `--wt-bg-chat` |
| `#E8EAEF #D9DEE7` | 9 | `--wt-line-2` / `--wt-line-3` |
| `#F3F8FE #F2F8FF #f4f7ff #f0f6ff #e8f1ff` | 8 | `--wt-bg-active` / `--wt-bg-pinned` / `--wt-brand-soft` |
| `#1d6bed`、`rgba(26,110,245,…)` | 3 | `--wt-brand` / `--wt-highlight` |
| `#FF4D4F #E0284F #FF381F #F44038` | 17 | `--wt-danger`（未读红改用 `--wt-badge-bg`） |
| `#36B37E #1A9E5F` | 14 | `--wt-success` |
| `#FA8C16 #F59E0B #B7791F #FF9D00` | 22 | `--wt-warning` / `--wt-brand` |
| `#0EA5E9` | 4 | `--wt-brand-text` |
| `#141414`（`dark:` 死代码） | 7 | `--wt-bg-panel` |

**保留不动**：`pages/wallet/token-icon.tsx` 里的链 / 币品牌色；`imim-dapps`、`imim:asset-card`、`OpenCorp-Config` 等功能性字符串；`public/mpc`、`src/generated/mpc`、wasm。
**直播间** `live.scss` 与 **客服** `components/CS*` 各有一张收口表，见第 8、9 节。

## 5. 组件对照

| pc-web | 新规格 | 要点 |
|---|---|---|
| `layout/TopSearchBar` | 40px，底色 `--wt-bg-frame` | **高度不改**（联动 `--searchbar-height`、Electron 拖拽区、`.chat-drawer`）；搜索框居中宽 1/3、高 28；左上 22px 小尺寸图标 `walletalk-icon-small.svg` |
| `layout/LeftNavBar` | 宽 60，按钮 48×52（图标 22 + 文字 11） | 选中态：`--wt-bg-raised` + `--wt-shadow-1`；三套图标统一换 `WtIcon` |
| `ConversationItem` | 行高 64，头像 44 | 人圆形、群圆角 30%；置顶 `--wt-bg-pinned`；当前 `--wt-bg-active` + 左侧 3px 琥珀条；未读 `--wt-badge-bg`，免打扰 `--wt-badge-muted-bg`；`[有人@你]` 用 `--wt-brand-text`，`[草稿]` 用 `--wt-danger` |
| `ChatHeader` | 56px + 36px 置顶条 | "群直播"胶囊去掉渐变，描边胶囊；直播中 = `--wt-brand-soft` 底 + `.wt-dot.is-live` |
| `MessageItem` | `.wt-bubble` / `.wt-bubble--self` + `.has-tail` | 自己的气泡琥珀实色 + 墨黑字，时间 / 已读用 `--wt-bubble-self-meta`，引用块 / 语音进度底用 `--wt-bubble-self-soft`，气泡里的 `@` 用 `--wt-mention-self` 加粗；去掉"左上 4px"；**头像与气泡底部对齐**（`align-items: flex-end`）；同人连续消息间距 2px，换人 8px |
| `AssetMessage`（transfer / request） | `.wt-wallet.wt-wallet--msg.wt-asset` | 状态：`paid·claimed·confirmed` → `.wt-status--done` + 常亮 `.wt-dot`；`pending·open·chain_pending` → `.wt-status--pending` + `.wt-dot.is-live` |
| `AssetMessage`（envelope） | `.wt-envelope` + `.wt-clasp > .wt-seal` | 已领 / 领完加 `.is-done`，过期加 `.is-expired`；点开加 `.is-opening`（560ms） |
| `ChatFooter` / `SendActionBar` | 工具栏 40、发送行 44，默认 25% 最小 200 不变 | 图标 20、热区 32；"资产"悬停 `--wt-brand-soft` |
| `GroupSetting` / `SingleSetting` / `SettingRow` | 抽屉 360，行高 48 | 分组间 8px `--wt-bg-subtle` 条；开关 `--wt-brand` |
| `UserCardModal` / `GroupCardModal` | 头图改为钱包皮面 + 琥珀暗纹 | 删除 `card_bg.png` 引用，参考 `ref.css` 的 `.r-ucard__cover` |
| `utils/common.ts` 首字母头像 6 组渐变 | `--wt-avatar-1…6-bg / -fg` | 同一明度的 6 个暖灰色相 |
| `pages/wallet` 头部 `balance-panel` | `.wt-wallet.wt-wallet--lg` | 总资产 36/600 等宽数字；扣环里放 MPC 状态；右侧 收款 / 转账（主）/ 兑换 + 安全摘要 |
| `wallet-tabs` | antd Tabs（主题已配） | 6 个 Tab 顺序不变 |
| `balance-rows` / `wallet-history` | 行高 56 | 金额右对齐 `tabular-nums`；链上确认中用呼吸圆点 |
| `useGlobalEvents` 新消息通知 `.imgo-msg-notify` | `--wt-bg-raised` + `--wt-shadow-2` | signature.css 已覆盖 |
| 弹窗 `no-padding-modal` 标题栏 | 52px、圆角 16 | 9 个遮罩为 0 的弹窗建议补 `--wt-bg-mask` |
| `layout/LeftNavBar/PersonalSettings` | 新增"外观"一项 | 放在"选择语言"下面，Checkbox 单选：跟随系统（默认）/ 白天 / 黑夜，写法与"点击关闭按钮时的事件"一致 |

## 6. 尺寸

| 令牌 | 值 | 用在 |
|---|---|---|
| `--wt-topbar-h` | 40px | 顶栏（不改） |
| `--wt-nav-w` | 60px | 左栏 |
| `--wt-conv-row-h` / `-m` | 64 / 68px | 会话行 PC / H5 |
| `--wt-chat-header-h` | 56px | 聊天头 |
| `--wt-drawer-w` | 360px | 设置抽屉 |
| `--wt-row-h` | 48px | 设置项、菜单项 |
| `--wt-table-row-h` | 56px | 资产行、交易记录 |
| `--wt-control-h` / `-sm` / `-lg` | 36 / 28 / 44px | 控件；H5 用 44 |
| `--wt-tabbar-h` | 66px | H5 TabBar（不含安全区） |

间距 4px 网格；圆角 6 / 8 / 10 / 14 / 18 / 20；字阶 11 / 12 / 13 / 14 / 15 / 16 / 18 / 22 / 28 / 36。

## 7. 个人设置 · 外观

- 位置：`PersonalSettings` 的"个人设置"里，"选择语言"下面。
- 控件：与相邻两项一致，用 Checkbox 做单选：**跟随系统**（默认）/ 白天 / 黑夜；下面一行说明"跟随系统时，电脑或手机切换深色模式，界面自动跟着变"。
- 数据：`appSettings.theme`，`updateAppSettings({ theme })`，持久化照 `locale`。H5 的"我的"页同样加这一项。
- 直播间不受这个设置影响，始终是黑夜。

## 8. 直播间 pages/live

**固定黑夜**：`.live-room` 最外层加 `data-theme="dark"`，里面全部用令牌；白天模式下也不会出现一圈亮边。结构不变：

| 区域 | 规格 |
|---|---|
| `.live-topbar` | 高 60，底 `#0B0D10`，底边 `--wt-line-1`；标题 15/600；状态胶囊：直播中 = `--wt-brand-soft-2` 底 + `--wt-brand-text` 字 + `.wt-dot.is-live`，等待开播 / 直播结束 = `--wt-bg-subtle`；模式标签描边；次行 主讲 / 在线 / 累计 / 点赞 / 已播 12px，数字 `tabular-nums`；右侧"群聊"（未读用 `--wt-badge-*`）、"场控 / 收起"（举手数徽标） |
| 舞台 | 底 `#07080A`；共享布局：主画面 + 右侧 176 宽连麦条，主讲小窗 2px `--wt-brand` 描边，其余 `rgba(255,247,236,.12)` 描边 |
| `.live-danmaku` | 左下堆叠，旧的向上淡出（保持现有 mask）；条目底 `rgba(12,10,8,.66)` + 暖白字 `#FFF7EC`，用户名 `#FFC96A`，自己的用 `#FFB224` |
| `LikeBurst` | 心形配色改为琥珀系四色：`#FFB224 #F38917 #FFC96A #E8762A` |
| `.artc-controlbar` | 胶囊 `rgba(15,17,20,.84)` + `blur(12px)`；按钮 40 圆形；关闭态红字红底 16%；共享中 `--wt-danger` 实底；演讲者 / 宫格用暗色分段 |
| `LivePlayer` 控件 | 右下，32 高，`rgba(0,0,0,.55)` 底 |
| `.live-side` | 340 宽，绝对定位从右侧滑入，底 `--wt-bg-panel`（黑夜值）；场控 / 在线用分段选项卡；行高 48，按钮 28 |
| `LiveChatDrawer` | 420 宽、右侧、`mask={false}` 保持；里面是标准聊天组件 |
| `.live-bottombar` | 高 64，底 `#0B0D10`；输入框 40 高、最宽 440；按钮 40 高；点赞图标琥珀实心；结束直播 = `danger-solid` |
| 结束确认 / 等待 / 结束 | 见在线文档"页面 · 直播间 · 开播前后" |
| `LiveCreateModal` | 跟随白天 / 黑夜；直播模式、开播时间用"选择卡"（选中 `--wt-brand-soft` 底 + 1.5px `--wt-brand` 描边） |
| H5（< 1024px） | 与现有断点一致：顶栏换行、输入独占一行、按钮 44 高 |

| live.scss 现在 | 用在 | 改为 |
|---|---|---|
| `#ff4d6d` × 11 | 直播中状态、点赞按钮、麦克风关闭、危险操作 | 直播中：`--wt-brand-soft-2` + 呼吸圆点；点赞：琥珀心；关闭与危险：`--wt-danger` |
| `#7C3AED`、`rgba(124,58,237,…)` | 主讲标记、主按钮、分段选中 | `--wt-brand`；主讲小窗描边 2px |
| `#2DD4BF`、`#9ec5ff` | 图标点缀、提示文字 | `--wt-text-2` / `--wt-text-3` |
| `#0e0e12`、`#1b1b26` | 舞台、连麦底、开场遮罩 | 舞台 `#07080A`；顶栏 / 底栏 `#0B0D10`；侧栏、抽屉 `--wt-bg-panel` |
| `rgba(255,255,255,.04–.88)` × 60+ | 描边、次级文字、浮层底 | 描边 `--wt-line-1/2`；文字 `--wt-text-2/3`；画面上的浮层 `rgba(0,0,0,.42–.55)` + `#FFF7EC` |

## 9. 客服 components/CS*

跟随白天 / 黑夜。坐席工作台内侧导航 208（`w-52`），列表行 58，统计卡 60，卡片圆角 14。

| 组件 | 规格 |
|---|---|
| `CSAgentPanel` 接待状态 | 分段：在线接待（琥珀状态灯）/ 忙碌（`--wt-danger` 点）/ 小休（空心环）/ 下线（`--wt-dot-off`）；右侧"接待 3/6 · 技能：…" |
| 排队等待 | 每行：头像 36、名字 + 来源标签、首条消息、"已等待 …"、接入；**超过 1 分钟整行 `--wt-brand-soft` 底**，等待时间 `--wt-brand-text` 加粗；标题旁"实时监听中"用呼吸圆点 |
| 我的接待 | "服务中 …"；进入 / 转接 / 更多（结束会话、备注、客户画像） |
| 下线引导横幅 | 原紫→青渐变改为**钱包皮面 + 琥珀暗纹**；四步流程卡；立即上线用主按钮 |
| `CSStatCards` | 图标 36 方块 `--wt-bg-subtle`；需要强调的一张用 `--wt-brand-soft-2`，数字 `--wt-brand-text` |
| `CSTicketPanel` | 优先级：紧急 `--wt-danger` 实底、高 `--wt-danger-soft`、普通灰、低描边；状态：处理中 = 琥珀标签 + 呼吸圆点、已解决 `--wt-success`；SLA 将到期 `--wt-warning`、已超时 `--wt-danger`；详情抽屉 420 |
| `CSManagerConsole` | 负载条 72×6：普通 `--wt-text-3`、≥ 80% `--wt-brand`、满负荷 `--wt-danger`（文字"已满负荷"）；分配规则用分段 |
| `CSVisitorPanel` | 入口卡用钱包皮面 + 琥珀暗纹；排队位次 64 方块 `--wt-brand-soft`，右上呼吸圆点 |
| `CSMessageRender` | `csCard`：竖条从紫色渐变改为 `--wt-brand` 实色，底用对方气泡色；邀请评价五星悬停 `--wt-amber`，评价后"感谢您的评价"用 `--wt-brand-text`；`csSystem`：居中灰条 `--wt-bg-subtle` |
| `SendActionBar` 坐席工具 | 快捷回复 / 知识库 / 转工单三个图标：`reply` / `folder` / `nav-tickets`；弹层 340 宽 |

| CS 现在 | 用在 | 改为 |
|---|---|---|
| `#7C3AED`、`#8759f2`、`#2DD4BF` | 接待中 / 留言的图标与计数、容量进度条、下线引导横幅 | 图标 `--wt-bg-subtle` + `--wt-text-2`，强调用 `--wt-brand-soft-2`；进度条见上；横幅改钱包皮面 |
| `#36b37e` | 在线状态点（带扩散动画）、已解决 | 在线：琥珀状态灯，"实时监听中"用呼吸；已解决：`--wt-success` |
| `#fa8c16`、`#ff9d00` | 忙碌状态、排队图标、计数胶囊 | 忙碌：`--wt-danger`；计数：`--wt-badge-*`；排队超时：`--wt-brand-soft` |
| `#ff4d4f` | 满负荷 | `--wt-danger` |
| `#f7f9fc #fafbfd #f6f8ff #d9dee7 #8d9bb0` | 面板底、描边、次级文字 | `--wt-bg-chat` / `--wt-bg-subtle` / `--wt-line-2` / `--wt-text-3` |

新增图标（直播与客服）：`screen-share` `hand` `like` `pip` `volume` `hang-up` `star`。

## 10. 已知的 antd 5.10 行为

antd 5.10 的主按钮在悬停 / 按下时文字仍取 `colorTextLightSolid`（白色），琥珀底上对比度不足。`walletalk-signature.css` 第 7 节已用 CSS 统一成墨黑字，**不要删这几行**。危险实底按钮的文字用 `--wt-on-danger`（白天白字、黑夜墨黑字）。

## 11. 验收清单

- [ ] 白天 / 黑夜各截一套：PC 1440、PC 1280、H5 390、Electron 窗口
- [ ] 会话、群聊、单聊、设置抽屉、通讯录、名片、钱包 6 个 Tab、转账 / 收款 / 红包消息各状态
- [ ] 直播间：主讲人（场控展开、共享中）、观众（群聊抽屉）、等待开播、直播结束、结束确认；白天模式下直播间仍是黑夜
- [ ] 客服：接待（在线 / 下线引导）、我的工单 + 详情、管理控制台、访客咨询（入口 / 排队 / 进行中 / 评价）
- [ ] 外观：跟随系统时切换电脑深色模式，界面跟着变；手动选白天 / 黑夜后不再跟随
- [ ] 全站（含直播间、客服）搜不到 `#7C3AED`、`#6D28D9`、`#8759f2`
- [ ] 黑夜模式下没有被 `html div` 压黑的文字
- [ ] 系统开启"减少动态效果"时，圆点、光圈、暗纹都停止
- [ ] `npm run typecheck`、`npm run build:local` 通过
