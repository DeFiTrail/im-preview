# Walletalk 设计系统 v1.0 · 前端接入说明

给 `clients/pc-web` 换皮用。PC 浏览器、Electron、H5 共用一套渲染层，所以这份包三端通用。
**只换皮，不改功能**：不动任何业务逻辑、接口、路由和功能性字符串。

在线文档（带白天 / 黑夜切换、全部组件和页面模板）：https://defitrail.github.io/im-preview/design-system/

---

## 1. 包里有什么

```
tokens/walletalk-tokens.css     令牌：白天（默认）+ 黑夜（data-theme="dark"）+ pc-web 旧变量映射
tokens/walletalk-tokens.json    同一份令牌的 JSON（设计工具、Flutter / 原生端可以用）
css/walletalk-signature.css     签名组件（钱包、状态灯、气泡尾巴、资产消息、红包）+ antd 补丁
antd/walletalk-antd-theme.ts    antd 5 主题：walletalkLight / walletalkDark（已在 antd 5.10.3 下类型检查、SSR 渲染通过）
tailwind/walletalk.preset.cjs   Tailwind 3 预设，兼容旧类名 bg-primary / text-primary
react/WtIcon.tsx                71 个图标的 React 组件，用法同 antd 图标
icons/svg/wt-*.svg              单个图标 SVG
icons/walletalk-icons.svg       图标 sprite
fonts/Outfit[wght].ttf + OFL.txt  品牌字体（SIL OFL，可商用、可随产品分发）
reference/ref.css               在线文档里参考实现的样式，对照尺寸用（不用引入到项目）
```

## 2. 五步接入

### ① 放文件

```
src/styles/walletalk-tokens.css
src/styles/walletalk-signature.css
src/styles/walletalk-antd-theme.ts
src/components/WtIcon.tsx
walletalk.preset.cjs              ← 与 tailwind.config.js 同级
public/fonts/Outfit[wght].ttf
```

### ② 引入样式（src/main.tsx）

先删掉 `src/styles/global.scss` 里 `:root` 的 10 个颜色变量（`--chat-bubble` `--chat-bubble-sender` `--base-black` `--primary` `--primary-active` `--top-search-bar` `--sub-text` `--gap-text` `--warn-text` `--moment-text`），**保留** `--full-height` `--searchbar-height` `--mobile-tabbar-height`。这 10 个变量已在 `walletalk-tokens.css` 里重新定义并指向新令牌。

```ts
import "./styles/walletalk-tokens.css";     // 放在 index.scss 之前
import "./index.scss";
import "./styles/walletalk-signature.css";  // 放在 antd.scss 之后
```

字体（建议自托管，国内网络稳定）：

```css
@font-face {
  font-family: "Outfit";
  src: url("/fonts/Outfit[wght].ttf") format("truetype");
  font-weight: 400 700;
  font-display: swap;
}
```

中文不额外加载字体，走系统：苹方 / 微软雅黑（已在 `--wt-font-ui` 字体栈里）。等宽字体 Geist Mono 只用于地址和哈希，缺失时回退系统等宽。

### ③ antd 主题 + 白天 / 黑夜（src/App.tsx）

```tsx
import { walletalkLight, walletalkDark } from "@/styles/walletalk-antd-theme";

const [mode, setMode] = useState<"light" | "dark">(() =>
  matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
useEffect(() => { document.documentElement.dataset.theme = mode; }, [mode]);

<ConfigProvider
  theme={mode === "dark" ? walletalkDark : walletalkLight}
  autoInsertSpaceInButton={false}
  locale={antdLocales[locale] ?? enUS}
  renderEmpty={() => <BrandEmpty />}
>
```

`mode` 建议放进现有的用户设置 store，并在"个人设置"里加一个"外观：跟随系统 / 白天 / 黑夜"。这属于设置项，是否本轮加请产品确认；不加也可以只跟随系统。

### ④ Tailwind（tailwind.config.js）

```js
module.exports = {
  presets: [require("./walletalk.preset.cjs")],
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  darkMode: "class",   // 保持不变。黑夜模式走 data-theme，不要给 <html> 加 .dark
  theme: { extend: { padding: {…}, margin: {…}, width: {…}, height: {…} } },  // 原有的保留
};
```

删掉原来 `extend.colors` 里的 `primary / primary-teal / primary-deep`（否则会覆盖预设）。新类名：

```
bg-wt-panel  bg-wt-chat  bg-wt-frame  bg-wt-active  bg-wt-input
text-wt-text-1 / -2 / -3  text-wt-brand-text  border-wt-line-1 / -2
bg-wt-brand  bg-wt-brand/10  text-wt-brand-on  rounded-wt-lg  shadow-wt-2  text-wt-body
```

### ⑤ 颜色收口

旧变量已自动映射（见第 3 节）。硬编码色按第 4 节的表机械替换。图标默认色改一处：

```ts
// src/constants/chatToolbarIcon.ts
color: "var(--wt-text-3)",
activeColor: "var(--wt-brand-text)",
```

## 3. 旧变量映射（已写在 walletalk-tokens.css）

| pc-web 变量 | 改为 | 说明 |
|---|---|---|
| `--primary` | `--wt-brand-text` | 40 处作文字 / 图标色。**另有 7 处作底色，要手动改**（见下） |
| `--primary-active` | `--wt-bg-active` | 42 处悬停 / 选中底 |
| `--top-search-bar` | `--wt-bg-frame` | 顶栏底色 |
| `--sub-text` | `--wt-text-3` | 110 处辅助文字 |
| `--gap-text` | `--wt-line-2` | 51 处描边 + 6 处分隔底 |
| `--base-black` | `--wt-text-1` | `html div` 全局文字色，随主题切换，黑夜下不再被压黑 |
| `--warn-text` | `--wt-danger` | 错误提示 |
| `--moment-text` | `--wt-brand-text` | 链接色 |
| `--chat-bubble` | `--wt-bg-subtle` | 33 处灰底（钱包、应用广场） |
| `--chat-bubble-sender` | `--wt-bubble-self-bg` | 自己的气泡底 |

`--primary` 作底色的 7 处，改成 `bg-[var(--wt-brand)]` + `text-[var(--wt-on-brand)]`（白字改墨黑字，白字在琥珀上只有 2.5:1）：

```
layout/CameraQrModal.tsx:188
styles/antd.scss:217, 222                     ← 可直接删除，signature.css 已接管
components/CSManagerConsole/index.tsx:1175, 1188
components/CSWorkbenchPanel/index.tsx:612, 625
```

## 4. 高频硬编码色替换表（不含 live.scss 与生成文件）

| 硬编码色 | 次数 | 替换为 |
|---|---|---|
| `#7C3AED` | 47 | 填充 `--wt-brand`；文字 / 图标 `--wt-brand-text` |
| `#6D28D9 #8B5CF6 #8759F2 #6366F1 #4F46E5` | 24 | `--wt-brand` / `--wt-brand-active` |
| `#2DD4BF #14B8A6`（紫→青渐变终点） | 13 | 删除渐变，改纯色 `--wt-brand` |
| `#667085` | 32 | `--wt-text-3` |
| `#8E9AB0 #8E9AAF #8D9BB0` | 20 | `--wt-text-3` |
| `#1F1F1F #1A2033 #0C1C33 #1F2329` | 26 | `--wt-text-1` |
| `#F4F5F7 #FAFBFD` | 21 | `--wt-bg-subtle` / `--wt-bg-panel` |
| `#F7F8FA` | 3 | `--wt-bg-chat` |
| `#E8EAEF #D9DEE7` | 9 | `--wt-line-2` / `--wt-line-3` |
| `#F3F8FE #F2F8FF #f4f7ff #f0f6ff #e8f1ff` | 8 | `--wt-bg-active` / `--wt-bg-pinned` / `--wt-brand-soft` |
| `#1d6bed`、`rgba(26,110,245,…)` | 3 | `--wt-brand` / `--wt-highlight` |
| `#FF4D4F #E0284F #FF381F #F44038` | 17 | `--wt-danger`（未读红改用 `--wt-badge-bg`） |
| `#36B37E #1A9E5F` | 14 | `--wt-success` |
| `#FA8C16 #F59E0B #B7791F #FF9D00` | 22 | `--wt-warning` / `--wt-brand` |
| `#0EA5E9` | 4 | `--wt-brand-text` |
| `#141414`（`dark:` 死代码） | 7 | `--wt-bg-panel` |

**保留不动**：`pages/wallet/token-icon.tsx` 里的链 / 币品牌色；`imim-dapps`、`imim:asset-card`、`OpenCorp-Config` 等功能性字符串；`public/mpc`、`src/generated/mpc`、wasm。
**直播间** `live.scss` 是独立深色体系，本轮只把其中的品牌紫（`#7C3AED` 系）换成 `--wt-brand`。

## 5. 组件对照

| pc-web | 新规格 | 要点 |
|---|---|---|
| `layout/TopSearchBar` | 40px，底色 `--wt-bg-frame` | **高度不改**（联动 `--searchbar-height`、Electron 拖拽区、`.chat-drawer`）；搜索框居中宽 1/3、高 28；左上 22px 小尺寸图标 `walletalk-icon-small.svg` |
| `layout/LeftNavBar` | 宽 60，按钮 48×52（图标 22 + 文字 11） | 选中态：`--wt-bg-raised` + `--wt-shadow-1`；三套图标统一换 `WtIcon` |
| `ConversationItem` | 行高 64，头像 44 | 人圆形、群圆角 30%；置顶 `--wt-bg-pinned`；当前 `--wt-bg-active` + 左侧 3px 琥珀条；未读 `--wt-badge-bg`，免打扰 `--wt-badge-muted-bg`；`[有人@你]` 用 `--wt-brand-text`，`[草稿]` 用 `--wt-danger` |
| `ChatHeader` | 56px + 36px 置顶条 | "群直播"胶囊去掉渐变，描边胶囊；直播中 = `--wt-brand-soft` 底 + `.wt-dot.is-live` |
| `MessageItem` | `.wt-bubble` / `.wt-bubble--self` + `.has-tail` | 去掉"左上 4px"；**头像与气泡底部对齐**（`align-items: flex-end`）；同人连续消息间距 2px，换人 8px |
| `AssetMessage`（transfer / request） | `.wt-wallet.wt-wallet--msg.wt-asset` | 状态：`paid·claimed·confirmed` → `.wt-status--done` + 常亮 `.wt-dot`；`pending·open·chain_pending` → `.wt-status--pending` + `.wt-dot.is-live` |
| `AssetMessage`（envelope） | `.wt-envelope` + `.wt-clasp > .wt-seal` | 已领 / 领完加 `.is-done`，过期加 `.is-expired`；点开加 `.is-opening`（560ms） |
| `ChatFooter` / `SendActionBar` | 工具栏 40、发送行 44，默认 25% 最小 200 不变 | 图标 20、热区 32；"资产"悬停 `--wt-brand-soft` |
| `GroupSetting` / `SingleSetting` / `SettingRow` | 抽屉 360，行高 48 | 分组间 8px `--wt-bg-subtle` 条；开关 `--wt-brand` |
| `UserCardModal` / `GroupCardModal` | 头图改为钱包皮面 + 琥珀暗纹 | 删除 `card_bg.png` 引用，参考 `ref.css` 的 `.r-ucard__cover` |
| `utils/common.ts` 首字母头像 6 组渐变 | `--wt-avatar-1…6-bg / -fg` | 同一明度的 6 个暖灰色相 |
| `pages/wallet` 头部 `balance-panel` | `.wt-wallet.wt-wallet--lg` | 总资产 36/600 等宽数字；扣环里放 MPC 状态；右侧 收款 / 转账（主）/ 兑换 + 安全摘要 |
| `wallet-tabs` | antd Tabs（主题已配） | 6 个 Tab 顺序不变 |
| `balance-rows` / `wallet-history` | 行高 56 | 金额右对齐 `tabular-nums`；链上确认中用呼吸圆点 |
| `useGlobalEvents` 新消息通知 `.imgo-msg-notify` | `--wt-bg-raised` + `--wt-shadow-2` | signature.css 已覆盖 |
| 弹窗 `no-padding-modal` 标题栏 | 52px、圆角 16 | 9 个遮罩为 0 的弹窗建议补 `--wt-bg-mask` |

## 6. 尺寸

| 令牌 | 值 | 用在 |
|---|---|---|
| `--wt-topbar-h` | 40px | 顶栏（不改） |
| `--wt-nav-w` | 60px | 左栏 |
| `--wt-conv-row-h` / `-m` | 64 / 68px | 会话行 PC / H5 |
| `--wt-chat-header-h` | 56px | 聊天头 |
| `--wt-drawer-w` | 360px | 设置抽屉 |
| `--wt-row-h` | 48px | 设置项、菜单项 |
| `--wt-table-row-h` | 56px | 资产行、交易记录 |
| `--wt-control-h` / `-sm` / `-lg` | 36 / 28 / 44px | 控件；H5 用 44 |
| `--wt-tabbar-h` | 66px | H5 TabBar（不含安全区） |

间距 4px 网格；圆角 6 / 8 / 10 / 14 / 18 / 20；字阶 11 / 12 / 13 / 14 / 15 / 16 / 18 / 22 / 28 / 36。

## 7. 已知的 antd 5.10 行为

antd 5.10 的主按钮在悬停 / 按下时文字仍取 `colorTextLightSolid`（白色），琥珀底上对比度不足。`walletalk-signature.css` 第 7 节已用 CSS 统一成墨黑字，**不要删这几行**。危险实底按钮的文字用 `--wt-on-danger`（白天白字、黑夜墨黑字）。

## 8. 验收清单

- [ ] 白天 / 黑夜各截一套：PC 1440、PC 1280、H5 390、Electron 窗口
- [ ] 会话、群聊、单聊、设置抽屉、通讯录、名片、钱包 6 个 Tab、转账 / 收款 / 红包消息各状态
- [ ] 全站搜不到 `#7C3AED` 和 `#6D28D9`（直播间除外）
- [ ] 黑夜模式下没有被 `html div` 压黑的文字
- [ ] 系统开启"减少动态效果"时，圆点、光圈、暗纹都停止
- [ ] `npm run typecheck`、`npm run build:local` 通过
