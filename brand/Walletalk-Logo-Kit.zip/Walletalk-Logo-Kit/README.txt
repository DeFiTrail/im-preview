﻿Walletalk 标志源文件包 v1.0（2026-09）

先看：Walletalk-Logo-Guidelines.pdf（标志视觉规范）

01-App-Icon   App 图标
  walletalk-icon.svg          圆角版（展示、网页、PPT 用）
  walletalk-icon-square.svg   方形满版（上架用，系统会自动裁圆角）
  walletalk-icon-small.svg    小尺寸版（16-24px 用）
  png/                        常用尺寸 PNG
  ios/AppIcon-1024.png        App Store / Xcode 用，不带透明通道
  android/                    自适应图标三层（前景 / 背景 / 单色）+ Play 商店 512
  web/                        favicon、apple-touch-icon、PWA 图标、site.webmanifest、head-snippet.html
02-Mark       符号（无底板）：渐变 / 纯橙 / 墨黑 / 白色
03-Wordmark   字标：彩色 / 反白 / 墨黑 / 白色
04-Lockup     横版、竖版组合：彩色 / 反白 / 墨黑 / 白色
05-PDF        主要版本的矢量 PDF（Illustrator 可直接打开编辑）
06-Font       Outfit 字体（SIL OFL 开源协议，可免费商用）
07-Tokens     色值与字体变量（CSS / JSON），给前端直接引用

文件命名：walletalk-[版本]-[配色].[格式]
  color   彩色，浅底用
  reverse 反白，深底用
  ink     墨黑单色
  white   白色单色

说明
- 所有文字和线条都已转为路径，打开文件不需要安装字体。
- SVG 可以直接拖进 Figma；PDF 可以用 Illustrator 打开。包里没有 .ai 文件，需要的话用 Illustrator 打开 PDF 另存即可。
- 主色 Amber #F38917；品牌渐变 #FFB224 → #E8600A（135°）；墨黑 Ink #17120C；暖白 Paper #FFF7EC；深色底 Night #0F1114。
- 白底上的橙色小字请用 Ember #B8470A。
